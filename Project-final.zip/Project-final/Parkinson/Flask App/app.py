import pickle
import cv2
from skimage import feature
#from tensorflow.keras.models import load_model
from flask import Flask,request,render_template
import os.path

app = Flask(__name__) #our flask app
#model = load_model("D:/csk/2021-22/AI & ML/Training/Project/Parkinson/training/model.pkl") #loading the model

model=pickle.loads(open("D:/csk/Project/Parkinson/parkinson.pkl","rb").read())
print("model loaded")
#model = load_model(r"D:\csk\2021-22\AI & ML\Training\Project\Parkinson\training\model.pkl")
                 
@app.route('/')
def index():
    return render_template('index6.html')

@app.route('/predict',methods = ['GET','POST'])
def upload():
   if request.method == 'POST':
       f=request.files['file']
       basepath=os.path.dirname(__file__)
       filepath=os.path.join(basepath,"uploads",f.filename)
       f.save(filepath)
       print("[INFO] loading the model...")
       #model=pickle.loads(open("model.pkl","rb").read())
       image=cv2.imread(filepath)
       output=image.copy()
       output=cv2.resize(output,(128,128))
       print("resizing....")
       image=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
       print(image)
       image=cv2.resize(image,(200,200))
       print("resizing....")
       image=cv2.threshold(image,0,255,
                           cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
       #image=cv2.threshold(image,0,255,cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
       print(image)
       #features=feature.hog(image,orientations=9,pixel_per_cell=(10,10),cells_per_block=(2,2),transform_sqrt=True,block_norm="L1")
       features=feature.hog(image,orientations=9,
                            pixels_per_cell=(10,10),cells_per_block=(2,2),
                            transform_sqrt=True, block_norm="L1")
       print(" features=",features)
       print("resizing....")
       preds=model.predict([features])
       print(preds)
       ls=["healthy","parkinson"]
       result=ls[preds[0]]
       color=(0,255,0) if result == "healthy" else (0,0,255)
       cv2.putText(output,result,(3,20),cv2.FONT_HERSHEY_SIMPLEX,0.5,color,2)
       cv2.imshow("output",output)
       cv2.waitKey(0)
       return result
   return None


if __name__ == '__main__':
    #app.run(host='0.0.0.0',port=8000,debug=False)
    app.run(debug = False, threaded = True)
    #app.run(debug = True) #running our flask app	
